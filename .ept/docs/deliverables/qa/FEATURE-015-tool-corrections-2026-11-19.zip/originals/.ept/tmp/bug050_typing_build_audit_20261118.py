"""Inspect fresh BUG-050 distributions against the frozen typing candidate."""
from email.parser import BytesParser
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
TMP = ROOT / '.ept/tmp'
WORK = TMP / 'bug050_geotemporal_fix_20261117'
OUT = TMP / 'bug050_typing_build_20261118'
MANIFEST = TMP / 'bug050_typing_candidate_manifest_20261118.json'
def sha(data):
    return hashlib.sha256(data).hexdigest()
assert sha(MANIFEST.read_bytes()) == '495a9a49f80d7e008fb24b1a03d4be3ec856eb065de7bab42f5e7a980864c4e7'
manifest = json.loads(MANIFEST.read_text())
for path, record in manifest['files'].items():
    assert sha((WORK / path).read_bytes()) == record['sha256'], path
assert subprocess.check_output(['git', '-C', str(WORK), 'write-tree']).decode().strip() == manifest['corrected_tree']
assert not subprocess.check_output(['git', '-C', str(WORK), 'diff', '--name-only']).strip()
wheel, = OUT.glob('*.whl')
sdist, = OUT.glob('*.tar.gz')
version = '0.1.6.dev15+ga8f23fd80.d20261118'
sources = [path for path in manifest['files'] if path.startswith('src/')]
records = []
with zipfile.ZipFile(wheel) as archive:
    info, = [name for name in archive.namelist() if name.endswith('.dist-info/METADATA')]
    metadata = BytesParser().parsebytes(archive.read(info))
    assert metadata['Version'] == version
    assert metadata['License-Expression'] == 'MIT AND Apache-2.0'
    assert set(metadata.get_all('License-File')) == {'LICENSE', 'LICENSE.foundry-sdk'}
    for path in sources:
        assert archive.read(path.removeprefix('src/')) == (WORK / path).read_bytes(), path
    for license in ('LICENSE', 'LICENSE.foundry-sdk'):
        assert archive.read(info.removesuffix('METADATA') + 'licenses/' + license) == (WORK / license).read_bytes()
    records.append({'path': str(wheel.relative_to(ROOT)), 'sha256': sha(wheel.read_bytes()), 'version': metadata['Version'], 'license_expression': metadata['License-Expression'], 'license_files': metadata.get_all('License-File'), 'three_product_source_files_byte_identical': True, 'full_license_bytes_identical': True})
with tarfile.open(sdist) as archive:
    prefix = archive.getnames()[0] + '/'
    metadata = BytesParser().parsebytes(archive.extractfile(prefix + 'PKG-INFO').read())
    assert metadata['Version'] == version
    assert metadata['License-Expression'] == 'MIT AND Apache-2.0'
    assert set(metadata.get_all('License-File')) == {'LICENSE', 'LICENSE.foundry-sdk'}
    for path in manifest['files']:
        assert archive.extractfile(prefix + path).read() == (WORK / path).read_bytes(), path
    assert archive.extractfile(prefix + 'LICENSE').read() == (WORK / 'LICENSE').read_bytes()
    records.append({'path': str(sdist.relative_to(ROOT)), 'sha256': sha(sdist.read_bytes()), 'version': metadata['Version'], 'license_expression': metadata['License-Expression'], 'license_files': metadata.get_all('License-File'), 'all_seven_candidate_files_byte_identical': True, 'recipe_byte_identical': True, 'full_license_bytes_identical': True})
proof = {'candidate_manifest_sha256': sha(MANIFEST.read_bytes()), 'candidate_tree': manifest['corrected_tree'], 'build_command': 'python -m build --outdir ../bug050_typing_build_20261118', 'build_exit_code': 0, 'isolated_build': True, 'wheel_built_from_sdist': True, 'generated_scm_version': version, 'build_log': {'path': '.ept/tmp/bug050_typing_build_20261118.log', 'sha256': sha((TMP / 'bug050_typing_build_20261118.log').read_bytes())}, 'audit_script_sha256': sha(Path(__file__).read_bytes()), 'distributions': records, 'candidate_unchanged_after_build': True, 'limits': ['Local Windows build from staged uncommitted correction; no package publication or hosted CI claim.', 'Prior wheel and sdist remain historical evidence for the pre-cast candidate.', 'No source, build requirement, version configuration, commit, push or tracker changes.']}
path = TMP / 'bug050_typing_build_proof_20261118.json'
path.write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({'proof': str(path.relative_to(ROOT)), 'sha256': sha(path.read_bytes()), 'distributions': records}, indent=2))

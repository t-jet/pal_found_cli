from pathlib import Path
import importlib.util
import json
import subprocess
import sys
import yaml
from datetime import date

root = Path(__file__).resolve().parent
candidate = root / 'bug051_devops_proposal_20261118'
evidence = root / 'bug051_backend_20261118'
evidence.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('guard', candidate / '.github/scripts/check_safety.py')
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)
policy = guard.build_policy(date(2026, 11, 18))
(evidence / 'active-policy.yml').write_text(yaml.safe_dump(policy))
meta = {'schema_version': '2.0.0', 'base_domain': 'https://example.invalid', 'packages': {}}
ids = sorted(guard.IDS)
cases = {}
for name in ['exact', 'unrelated', 'expired']:
    db = evidence / name
    db.mkdir(exist_ok=True)
    entries = [{'ids': [{'type': 'pyup', 'id': advisory}], 'specs': ['==3.32.7'],
                'advisory': 'Synthetic boundary fixture, not a real advisory claim.',
                'affected_versions': ['3.32.7'], 'fixed_versions': []}
               for advisory in ids + (['SFTY-20990101-99999'] if name == 'unrelated' else [])]
    (db / 'insecure.json').write_text(json.dumps({'meta': meta, 'vulnerable_packages': {'filelock': ['==3.32.7']}}))
    (db / 'insecure_full.json').write_text(json.dumps({'meta': meta, 'vulnerable_packages': {'filelock': entries}}))
    selected = json.loads(json.dumps(policy))
    if name == 'expired':
        selected['security']['ignore-vulnerabilities'][ids[0]]['expires'] = '2026-11-17'
    path = db / 'policy.yml'
    path.write_text(yaml.safe_dump(selected))
    result = subprocess.run([sys.executable, '-m', 'safety', 'check', '--full-report', '--cache', '0', '--policy-file', str(path), '--db', str(db), '--disable-audit-and-monitor'], cwd=candidate, capture_output=True, text=True, encoding='utf-8', errors='replace')
    (evidence / f'{name}.log').write_text(result.stdout + result.stderr, encoding='utf-8')
    cases[name] = {'exit': result.returncode, 'synthetic': True}
print(json.dumps(cases))
(evidence / 'results.json').write_text(json.dumps(cases, indent=2))

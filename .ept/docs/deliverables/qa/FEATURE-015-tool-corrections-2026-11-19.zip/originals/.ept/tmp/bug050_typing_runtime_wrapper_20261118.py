"""Run the unchanged independent harness with the corrected candidate manifest."""
import hashlib
from pathlib import Path
import runpy
from unittest.mock import patch

root = Path(__file__).resolve().parents[2]
harness = root / '.ept/tmp/bug050_extended_runtime_finish_20261118b.py'
manifest = root / '.ept/tmp/bug050_typing_candidate_manifest_20261118.json'
assert hashlib.sha256(harness.read_bytes()).hexdigest() == 'dd0c2ace3bb53942604ade11ef29bdcffaacd32fc4ac34b21cc16b3ea7cc3123'
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == '495a9a49f80d7e008fb24b1a03d4be3ec856eb065de7bab42f5e7a980864c4e7'
original_read_text = Path.read_text
old_manifest = root / '.ept/tmp/bug050_candidate_manifest_20261118.json'

def candidate_read_text(path, *args, **kwargs):
    if path.resolve() == old_manifest.resolve():
        return original_read_text(manifest, *args, **kwargs)
    return original_read_text(path, *args, **kwargs)

with patch.object(Path, 'read_text', candidate_read_text):
    runpy.run_path(str(harness), run_name='__main__')

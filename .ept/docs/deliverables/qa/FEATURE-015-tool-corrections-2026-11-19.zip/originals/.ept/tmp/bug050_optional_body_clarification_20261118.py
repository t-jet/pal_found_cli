"""Identify exact HTTP bodies accepted by the native optional response decoder."""
import hashlib
import importlib.metadata
import inspect
import json
from pathlib import Path
import sys
from typing import Optional

root = Path(__file__).resolve().parents[2]
if sys.argv[1] == '179':
    sys.path.insert(0, str(root / '.ept/tmp/bug050_sdk179_runtime'))
sys.path.insert(0, str(root / '.ept/tmp/bug050_geotemporal_fix_20261117/src'))
import httpx
from foundry_sdk import _core

version = importlib.metadata.version('foundry-platform-sdk')
if version == '1.79.0':
    from foundry_sdk.v2.ontologies.models import GeotemporalSeriesEntry
else:
    from pal_found_cli.ontologies._legacy_geotemporal_models import GeotemporalSeriesEntry

request_info = _core.RequestInfo(method='GET', resource_path='/unused-offline', query_params={}, path_params={}, header_params={}, body=None, request_timeout=None, response_type=Optional[GeotemporalSeriesEntry], throwable_errors={})
rows = []
for kind, response in [('harness-json-none', httpx.Response(200, json=None)), ('empty-200', httpx.Response(200, content=b'')), ('empty-204', httpx.Response(204, content=b'')), ('literal-json-null-200', httpx.Response(200, content=b'null', headers={'content-type': 'application/json'}))]:
    for response_class in (_core.ApiResponse, _core.AsyncApiResponse):
        row = {'fixture': kind, 'status': response.status_code, 'body_hex': response.content.hex(), 'headers': dict(response.headers), 'decoder': response_class.__name__}
        try:
            value = response_class(request_info, response).decode()
            row.update(result_type=type(value).__name__, result=value)
        except Exception as error:
            row.update(error_type=type(error).__name__, error=str(error))
        rows.append(row)

source = Path(inspect.getfile(_core.AsyncApiResponse))
result = {'sdk': version, 'model': GeotemporalSeriesEntry.__module__ + '.' + GeotemporalSeriesEntry.__name__, 'native_decoder_source': str(source), 'native_decoder_source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'decode_source': inspect.getsource(_core.AsyncApiResponse.decode), 'rows': rows, 'scope': 'Direct native response decoding only. Previous 197 CLI checks used HTTP200 empty-body fixture; no literal JSON-null acceptance was tested there.'}
target = root / f'.ept/tmp/bug050_optional_body_clarification_{version}_20261118.json'
target.write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({'sdk': version, 'rows': rows, 'result_path': str(target), 'result_sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))

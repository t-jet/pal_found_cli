"""Independent production CLI contract checks using native SDK HTTP transport."""
import ast
import faulthandler
faulthandler.dump_traceback_later(45, exit=True)
import asyncio
import contextlib
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / '.ept/tmp/bug050_geotemporal_fix_20261117'
OUT = ROOT / '.ept/tmp/bug050_independent_runtime_qa_finish_20261118b' / sys.argv[1]
OUT.mkdir(parents=True, exist_ok=False)
if sys.argv[1].startswith('179'):
    sys.path.insert(0, str(ROOT / '.ept/tmp/bug050_sdk179_runtime'))
sys.path.insert(0, str(WORK / 'src'))
import httpx
import toon_format
from foundry_sdk import ATTRIBUTION_VAR, SAMPLED_VAR, SPAN_ID_VAR, TRACE_ID_VAR
from foundry_sdk._core import AsyncApiResponse
from foundry_sdk._core.http_client import AsyncHttpClient
from pal_found_cli.ontologies import _geotemporal_compat as compat
from pal_found_cli.ontologies.scripts import pal_found_ontologies_cli as cli

VERSION = importlib.metadata.version('foundry-platform-sdk')
LATEST = 'get-geotemporal-series-latest-value'
HIST = 'stream-geotemporal-series-historic-values'
ARGS = ['ont/%', 'T ?#', 'key/%?#', 'loc/name']
PREFIX = '/api/v2/ontologies/ont%2F%25/objects/T%20%3F%23/key%2F%25%3F%23/geotemporalSeries/loc%2Fname/'
POINT = {'time': '2026-10-31T03:04:05+02:00', 'position': {'type': 'Point', 'coordinates': [1.25, 2.5, 3.75], 'bbox': [1, 2, 3, 4]}}
DATA = b'\x00\xffown-QA\n\x80'
checks = []
evidence = []
base_manifest = json.loads((ROOT / '.ept/tmp/bug050_candidate_manifest_20261118.json').read_text())
frozen = {p: hashlib.sha256((WORK / p).read_bytes()).hexdigest() for p in base_manifest['files']}
assert all(frozen[p] == v['sha256'] for p, v in base_manifest['files'].items())
SDK_REPO = ROOT / '.ept/docs/customer_input/foundry-platform-python'
old = subprocess.check_output(['git', '-C', str(SDK_REPO), 'show', '2da67907be429c35f747eef565867ce81dd2cafc:foundry_sdk/v2/ontologies/geotemporal_series_property.py'])
assert hashlib.sha256(old).hexdigest() == '982aa99518e050ab486e4a28eb524f1748b0337fe2f50803d4c948116cd48c56'
tree = ast.parse(old)
old_cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'AsyncGeotemporalSeriesPropertyClient')
source_wire = {}
for n in old_cls.body:
    if getattr(n, 'name', '') in (LATEST.replace('-', '_'), HIST.replace('-', '_')):
        req = next(x for x in ast.walk(n) if isinstance(x, ast.Call) and isinstance(x.func, ast.Attribute) and x.func.attr == 'RequestInfo')
        source_wire[n.name] = {k.arg: ast.unparse(k.value) for k in req.keywords}
assert len(source_wire) == 2 and all(x['throwable_errors'] == '{}' for x in source_wire.values())

def denied(*a, **kw):
    raise AssertionError('External network forbidden')

original_connect = socket.socket.connect
def connect(sock, address):
    if isinstance(address, tuple) and address[0] in ('127.0.0.1', '::1'):
        return original_connect(sock, address)
    return denied(address)

def invoke(name, op=LATEST, *, flags=(), payload=POINT, env=None, mode='ok', output='json', mutation=None):
    folder = OUT / name
    folder.mkdir()
    empty = folder / 'empty.env'
    empty.write_text('')
    settings = {
        'FOUNDRY_AGENTIC_CLI_ENV_FILE': str(empty), 'FOUNDRY_TOKEN': 'independent-native-token',
        'FOUNDRY_HOSTNAME': 'https://qa-native.invalid', 'FOUNDRY_AGENTIC_CLI_ENABLED': 'true',
        'FOUNDRY_AGENTIC_CLI_READONLY': 'false', 'FOUNDRY_AGENTIC_CLI_METADATA_ONLY': 'false',
        'FOUNDRY_AGENTIC_CLI_DOWNLOAD_PATH': str(folder / 'downloads'),
        'FOUNDRY_AGENTIC_CLI_SESSION_PATH': str(folder / 'sessions'),
        'FOUNDRY_AGENTIC_CLI_RETRY_MAX_ATTEMPTS': '2',
        'FOUNDRY_AGENTIC_CLI_RETRY_INITIAL_DELAY_MS': '0', 'FOUNDRY_AGENTIC_CLI_RETRY_MAX_DELAY_MS': '0',
        'FOUNDRY_AGENTIC_CLI_LOG_LEVEL': 'CRITICAL', 'FOUNDRY_AGENTIC_CLI_ENABLE_TRACING': 'true',
        'FOUNDRY_AGENTIC_CLI_ENABLE_ATTRIBUTION': 'true',
        'FOUNDRY_AGENTIC_CLI_ATTRIBUTION_RIDS': 'ri.foundry.main.dataset.independent',
    }
    settings.update(env or {})
    requests, decoded, clients, context_seen = [], [], [], []
    closed = []
    original_init = AsyncHttpClient.__init__
    original_decode = AsyncApiResponse.decode
    def init(client, *a, **kw):
        original_init(client, *a, **kw)
        clients.append(client)
    def decode(response):
        result = original_decode(response)
        if mutation == 'model' and result is not None:
            result = {'modern': 'untyped map'}
        decoded.append(result)
        return result
    async def respond(request):
        requests.append(request)
        context_seen.append(tuple(v.get() for v in variables))
        if mode == 'timeout':
            try:
                await asyncio.Event().wait()
            finally:
                closed.append(True)
        if mode == 'cancel':
            try:
                raise asyncio.CancelledError('independent cancel')
            finally:
                closed.append(True)
        if mode in ('retry_once', 'retry_exhaust') and (mode == 'retry_exhaust' or len(requests) == 1):
            raise httpx.ReadTimeout('independent interrupted transport', request=request)
        if isinstance(mode, int):
            return httpx.Response(mode, json={'errorCode': {400: 'INVALID_ARGUMENT', 403: 'PERMISSION_DENIED', 404: 'NOT_FOUND', 409: 'CONFLICT', 429: 'RATE_LIMIT', 503: 'UNAVAILABLE'}[mode], 'errorName': 'IndependentGeneral', 'errorInstanceId': '00000000-0000-0000-0000-000000000099', 'parameters': {'qa': 'native'}})
        if mode == 'partial':
            class Broken(httpx.AsyncByteStream):
                async def __aiter__(self):
                    yield b'partial'
                    raise httpx.ReadError('independent partial read', request=request)
                async def aclose(self):
                    closed.append(True)
            return httpx.Response(200, stream=Broken())
        return httpx.Response(200, json=payload) if op == LATEST else httpx.Response(200, content=DATA)
    variables = (TRACE_ID_VAR, SPAN_ID_VAR, SAMPLED_VAR, ATTRIBUTION_VAR)
    prior = ('a' * 32, 'b' * 16, '0', ['ri.foundry.main.dataset.outer'])
    tokens = [v.set(x) for v, x in zip(variables, prior)]
    stdout, stderr = io.StringIO(), io.StringIO()
    code = None
    cancelled = False
    with contextlib.ExitStack() as stack:
        stack.enter_context(patch.dict(os.environ, settings, clear=True))
        stack.enter_context(patch.object(sys, 'argv', ['pal-found-ontologies', 'geotemporal-series-property', op, *ARGS, *flags, '--format', output]))
        for target in ('socket.getaddrinfo', 'socket.create_connection', 'httpx.HTTPTransport.handle_request', 'httpx.AsyncHTTPTransport.handle_async_request'):
            stack.enter_context(patch(target, denied))
        stack.enter_context(patch.object(socket.socket, 'connect', connect))
        stack.enter_context(patch.object(AsyncHttpClient, '__init__', init))
        stack.enter_context(patch.object(AsyncApiResponse, 'decode', decode))
        stack.enter_context(patch('foundry_sdk._core.http_client._get_async_transport', lambda *a, **kw: httpx.MockTransport(respond)))
        if VERSION == '1.79.0':
            stack.enter_context(patch.object(compat._LegacyGeotemporalClient, '__init__', denied))
        if mutation == 'route':
            stack.enter_context(patch.object(compat, '_PREFIX', '/v2/deliberate-wrong-route/'))
        if mutation in ('save-failure', 'save-cancel'):
            async def interrupted_chunks(*args, **kwargs):
                try:
                    yield DATA[:3]
                    if mutation == 'save-cancel':
                        raise asyncio.CancelledError('cancel after temporary write')
                    raise OSError('failure after temporary write')
                finally:
                    closed.append(True)
            stack.enter_context(patch.object(cli, '_bytes_iter', interrupted_chunks))
        if mutation == 'publish':
            stack.enter_context(patch('pal_found_cli.common.binary_download_handler.os.replace', side_effect=OSError('independent atomic publication fault')))
        if mutation == 'guard':
            stack.enter_context(patch.object(cli.AccessControlGuard, 'check', lambda *a, **kw: None))
        if mutation == 'cleanup':
            stack.enter_context(patch('pal_found_cli.common.binary_download_handler.os.replace', side_effect=OSError('independent atomic publication fault')))
            stack.enter_context(patch.object(Path, 'unlink', lambda *a, **kw: None))
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            try:
                code = cli.console_main()
            except asyncio.CancelledError:
                cancelled = True
            finally:
                for client in clients:
                    asyncio.run(client.aclose())
    restored = tuple(v.get() for v in variables) == prior
    for v, t in zip(variables, tokens):
        v.reset(t)
    raw = stdout.getvalue()
    try:
        result = json.loads(raw)
    except json.JSONDecodeError:
        result = toon_format.loads(raw) if raw.strip() else None
    row = {'name': name, 'operation': op, 'code': code, 'cancelled': cancelled, 'result': result,
           'requests': [{'method': r.method, 'url': str(r.url), 'body': r.content.decode(), 'headers': {k: v for k, v in r.headers.items() if k != 'authorization'}, 'token_valid': r.headers.get('authorization') == 'Bearer independent-native-token', 'timeout': r.extensions.get('timeout')} for r in requests],
           'decoded_types': [type(x).__module__ + '.' + type(x).__name__ for x in decoded], 'sdk_constructions': len(clients), 'context_restored': restored, 'transport_closed': bool(closed), 'stderr': stderr.getvalue()}
    evidence.append(row)
    assert restored, name
    if requests:
        for request, during in zip(requests, context_seen):
            assert request.headers['authorization'] == 'Bearer independent-native-token'
            assert request.headers['attribution'] == 'ri.foundry.main.dataset.independent'
            assert request.headers['x-b3-traceid'] == during[0] != prior[0]
            assert request.headers['x-b3-spanid'] == during[1] != prior[1]
            assert 'traceparent' not in request.headers
    return row, requests, decoded, folder

def check(name, fn):
    try:
        fn()
        checks.append({'name': name, 'pass': True})
    except BaseException as exc:
        checks.append({'name': name, 'pass': False, 'type': type(exc).__name__, 'error': str(exc)})

def latest_case(name, payload, fmt, query):
    flags = ['--timeout', '9'] + (['--sdk-package-rid', 'ri.foundry.main.sdk-package.qa', '--sdk-version', '3.0+q'] if query else [])
    row, reqs, values, _ = invoke(name, payload=payload, output=fmt, flags=flags)
    assert row['code'] == 0 and len(reqs) == 1, row
    req = reqs[0]
    assert req.url.raw_path.split(b'?')[0].decode() == PREFIX + 'latestValue'
    assert req.method == 'GET' and req.content == b'' and req.headers['accept'] == 'application/json'
    assert dict(req.url.params) == ({'sdkPackageRid': 'ri.foundry.main.sdk-package.qa', 'sdkVersion': '3.0+q'} if query else {})
    assert req.extensions['timeout']['read'] == 9
    if payload is None:
        assert values == [None] and row['result'] is None
    else:
        assert type(values[0]).__name__ == 'GeotemporalSeriesEntry' and type(values[0].position).__name__ == 'GeoPoint'
        assert values[0].time.utcoffset().total_seconds() == 7200
        assert row['result']['position'] == POINT['position']

for fmt in ('json', 'toon'):
    for null in (False, True):
        for query in (False, True):
            name = f'latest-{fmt}-{null}-{query}'
            check(name, lambda n=name, p=None if null else POINT, f=fmt, q=query: latest_case(n, p, f, q))

ranges = [None, 'null', {'type': 'absolute'}, {'type': 'absolute', 'startTime': '2026-01-01T00:00:00+02:00'}, {'type': 'absolute', 'endTime': '2026-02-01T00:00:00Z'}, {'type': 'relative', 'startTime': {'when': 'BEFORE', 'value': 7, 'unit': 'MINUTES'}, 'endTime': {'when': 'AFTER', 'value': 2, 'unit': 'DAYS'}}]
def historic_case(index, range_):
    flags = [] if range_ is None else ['--range', range_ if isinstance(range_, str) else json.dumps(range_)]
    row, reqs, values, folder = invoke(f'historic-range-{index}', HIST, flags=flags + ['--sdk-version', '3+own'])
    assert row['code'] == 0 and len(reqs) == 1, row
    req = reqs[0]
    assert req.url.raw_path.split(b'?')[0].decode() == PREFIX + 'streamHistoricValues'
    assert req.method == 'POST' and dict(req.url.params) == {'sdkVersion': '3+own'}
    assert req.headers['accept'] == '*/*' and req.headers['content-type'] == 'application/json'
    expected = {} if range_ in (None, 'null') else {'range': range_}
    if index == 3:
        expected = {'range': {'type': 'absolute', 'startTime': '2025-12-31T22:00:00+00:00'}}
    if index == 4:
        expected = {'range': {'type': 'absolute', 'endTime': '2026-02-01T00:00:00+00:00'}}
    assert json.loads(req.content) == expected
    assert values == [DATA] and type(values[0]) is bytes
    result = row['result']
    assert Path(result['file_path']).is_relative_to(folder / 'downloads')
    assert Path(result['file_path']).read_bytes() == DATA
    assert result['file_size'] == len(DATA) and result['source_size'] == len(DATA) and result['truncated'] is False
    assert result['checksum_sha256'] == hashlib.sha256(DATA).hexdigest() and result['checksum_md5'] == hashlib.md5(DATA).hexdigest()
for i, r in enumerate(ranges):
    check(f'historic-range-{i}', lambda i=i, r=r: historic_case(i, r))

bad_ranges = [{'type': 'unknown'}, {'type': 'absolute', 'startTime': '2026-01-01T00:00:00'}, {'type': 'relative', 'startTime': {'when': 'INVALID', 'value': 1, 'unit': 'DAYS'}}, {'type': 'relative', 'startTime': {'when': 'BEFORE', 'value': 1, 'unit': 'BANANAS'}}]
for i, r in enumerate(bad_ranges):
    def invalid(i=i, r=r):
        row, reqs, _, _ = invoke(f'invalid-range-{i}', HIST, flags=['--range', json.dumps(r)])
        assert row['code'] == 1 and not reqs, row
    check(f'invalid-range-{i}', invalid)
for i, p in enumerate([{'time': '2026-01-01T00:00:00', 'position': POINT['position']}, {'time': POINT['time'], 'position': {'type': 'LineString', 'coordinates': [1, 2]}}, {'time': POINT['time']}, {'modern': 'map'}]):
    def invalid(i=i, p=p):
        row, reqs, _, _ = invoke(f'invalid-latest-{i}', payload=p)
        assert row['code'] != 0 and len(reqs) == 1, row
    check(f'invalid-latest-{i}', invalid)

for op in (LATEST, HIST):
    for tier in ('global', 'namespace', 'operation', 'metadata', 'precedence'):
        def guard(op=op, tier=tier):
            op_key = 'FOUNDRY_AGENTIC_CLI_ONTOLOGIES_GEOTEMPORAL_SERIES_PROPERTY_' + op.replace('-', '_').upper() + '_ENABLED'
            env = { {'global': 'FOUNDRY_AGENTIC_CLI_ENABLED', 'namespace': 'FOUNDRY_AGENTIC_CLI_ONTOLOGIES_ENABLED', 'operation': op_key, 'metadata': 'FOUNDRY_AGENTIC_CLI_METADATA_ONLY', 'precedence': 'FOUNDRY_AGENTIC_CLI_ENABLED'}[tier]: 'true' if tier == 'metadata' else 'false'}
            if tier == 'precedence':
                env[op_key] = 'true'
                env['FOUNDRY_AGENTIC_CLI_ONTOLOGIES_ENABLED'] = 'true'
            env['FOUNDRY_TOKEN'] = ''
            row, reqs, _, _ = invoke(f'guard-{op}-{tier}', op, env=env)
            assert row['code'] == 8 and not reqs and row['sdk_constructions'] == 0 and row['result']['exception_type'] == 'AccessControlError', row
        check(f'guard-{op}-{tier}', guard)
    def readonly(op=op):
        row, reqs, _, _ = invoke(f'readonly-{op}', op, env={'FOUNDRY_AGENTIC_CLI_READONLY': 'true'})
        assert row['code'] == 0 and len(reqs) == 1, row
    check(f'readonly-{op}', readonly)
    for status, code in ((400, 1), (403, 3), (404, 4), (409, 1), (429, 7), (503, 6)):
        def error(op=op, status=status, code=code):
            row, reqs, _, _ = invoke(f'error-{op}-{status}', op, mode=status)
            assert row['code'] == code and len(reqs) == (2 if status in (429, 503) else 1), row
            assert row['result']['error'] is True and row['result']['exception_type'] != 'AttributeError', row
        check(f'error-{op}-{status}', error)
    for mode in ('retry_once', 'retry_exhaust', 'timeout', 'cancel', 'partial'):
        def fault(op=op, mode=mode):
            row, reqs, _, folder = invoke(f'fault-{op}-{mode}', op, mode=mode, flags=['--timeout', '1'], env={'FOUNDRY_AGENTIC_CLI_RETRY_MAX_ATTEMPTS': '1' if mode in ('timeout', 'cancel', 'partial') else '2'})
            assert len(reqs) == (2 if mode in ('retry_once', 'retry_exhaust') else 1), row
            if mode == 'retry_once':
                assert row['code'] == 0 and reqs[0].url == reqs[1].url and reqs[0].content == reqs[1].content, row
            else:
                assert row['cancelled'] if mode == 'cancel' else row['code'] != 0, row
                assert not list((folder / 'downloads').rglob('*')), row
            if mode in ('cancel', 'timeout', 'partial'):
                assert row['transport_closed'], row
        check(f'fault-{op}-{mode}', fault)

for limit in (1, len(DATA), len(DATA) + 1):
    def bound(limit=limit):
        row, _, _, _ = invoke(f'bound-{limit}', HIST, env={'FOUNDRY_AGENTIC_CLI_MAX_DOWNLOAD_BYTES': str(limit)})
        r = row['result']; expected = DATA[:limit]
        assert row['code'] == 0 and Path(r['file_path']).read_bytes() == expected and r['truncated'] == (limit < len(DATA)), row
        assert r['file_size'] == len(expected) and r['checksum_sha256'] == hashlib.sha256(expected).hexdigest()
    check(f'bound-{limit}', bound)
def publish():
    row, reqs, _, folder = invoke('publish-failure', HIST, mutation='publish')
    assert row['code'] != 0 and len(reqs) == 1 and not [p for p in (folder / 'downloads').rglob('*') if p.is_file()], row
check('publish-failure', publish)

if VERSION != '1.79.0':
    def negative_route():
        row, reqs, _, _ = invoke('negative-route', mutation='route')
        assert row['code'] == 0
        try:
            assert reqs[0].url.raw_path.decode() == PREFIX + 'latestValue'
        except AssertionError:
            return
        raise AssertionError('Wire oracle missed deliberate wrong route')
    check('negative-route-oracle-detects', negative_route)

def negative_model():
    row, reqs, values, _ = invoke('negative-model', mutation='model')
    assert len(reqs) == 1 and type(values[0]).__name__ != 'GeotemporalSeriesEntry'
    assert row['result'] != POINT
check('negative-model-oracle-detects', negative_model)

def negative_guard():
    row, reqs, _, _ = invoke('negative-guard', mutation='guard', env={'FOUNDRY_AGENTIC_CLI_ENABLED': 'false'})
    assert row['code'] != 8 and len(reqs) == 1 and row['sdk_constructions'] > 0
check('negative-guard-oracle-detects', negative_guard)

def negative_cleanup():
    row, reqs, _, folder = invoke('negative-cleanup', HIST, mutation='cleanup')
    assert row['code'] != 0 and len(reqs) == 1
    assert list((folder / 'downloads').rglob('*.tmp')), row
check('negative-cleanup-oracle-detects', negative_cleanup)

for fault in ('save-failure', 'save-cancel'):
    def saving_fault(fault=fault):
        row, reqs, _, folder = invoke(fault, HIST, mutation=fault)
        assert len(reqs) == 1 and row['transport_closed'], row
        assert row['cancelled'] if fault == 'save-cancel' else row['code'] != 0, row
        assert not list((folder / 'downloads').rglob('*')), row
    check(fault, saving_fault)

assert frozen == {p: hashlib.sha256((WORK / p).read_bytes()).hexdigest() for p in frozen}
result = {'verdict': 'PASS' if all(c['pass'] for c in checks) else 'FAIL', 'sdk': VERSION, 'checks': checks, 'evidence': evidence, 'frozen_source_sha256': frozen, 'legacy_source_wire': source_wire, 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'limits': ['Offline native client only; backend availability unverified.', 'No all-version support or publication acceptance claim.', 'Seven-file final manifest binding required separately.']}
target = OUT / 'result.json'
target.write_text(json.dumps(result, indent=2, default=str), encoding='utf-8')
print(json.dumps({'verdict': result['verdict'], 'sdk': VERSION, 'checks': len(checks), 'failures': [c for c in checks if not c['pass']], 'result': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))
sys.exit(0 if result['verdict'] == 'PASS' else 1)
